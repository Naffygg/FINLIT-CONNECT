import { useState } from "react";
import Hero from "@/components/Hero";
import OnboardingFlow from "@/components/OnboardingFlow";
import Dashboard from "@/components/Dashboard";
import QuizComponent from "@/components/QuizComponent";

const Index = () => {
  const [currentView, setCurrentView] = useState<'hero' | 'onboarding' | 'dashboard' | 'quiz'>('hero');
  const [userData, setUserData] = useState({
    name: '',
    age: '',
    language: ''
  });

  const handleStartLearning = () => {
    setCurrentView('onboarding');
  };

  const handleOnboardingComplete = (data: { name: string; age: string; language: string }) => {
    setUserData(data);
    setCurrentView('dashboard');
  };

  const handleStartQuiz = () => {
    setCurrentView('quiz');
  };

  const handleQuizComplete = (score: number) => {
    // In a real app, this would update the user's progress
    console.log(`Quiz completed with score: ${score}`);
    setCurrentView('dashboard');
  };

  if (currentView === 'hero') {
    return <Hero onStartLearning={handleStartLearning} />;
  }

  if (currentView === 'onboarding') {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  if (currentView === 'quiz') {
    return <QuizComponent onComplete={handleQuizComplete} />;
  }

  return <Dashboard userName={userData.name} userLanguage={userData.language} onStartQuiz={handleStartQuiz} />;
};

export default Index;
