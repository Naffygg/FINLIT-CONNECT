import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";
import { useState } from "react";

const languages = [
  { code: 'en', name: 'English', native: 'English' },
  { code: 'ha', name: 'Hausa', native: 'Hausa' },
  { code: 'yo', name: 'Yoruba', native: 'Yorùbá' },
  { code: 'ig', name: 'Igbo', native: 'Igbo' },
  { code: 'pcm', name: 'Pidgin', native: 'Naija Pidgin' },
];

interface LanguageSelectorProps {
  onLanguageSelect: (language: string) => void;
  onNext: () => void;
}

export default function LanguageSelector({ onLanguageSelect, onNext }: LanguageSelectorProps) {
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const handleLanguageSelect = (langCode: string) => {
    setSelectedLanguage(langCode);
    onLanguageSelect(langCode);
  };

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-6 shadow-strong">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-primary mb-2">Choose Your Language</h2>
          <p className="text-muted-foreground">Select your preferred language for learning</p>
        </div>

        <div className="space-y-3 mb-6">
          {languages.map((language) => (
            <button
              key={language.code}
              onClick={() => handleLanguageSelect(language.code)}
              className={`w-full p-4 rounded-lg border-2 transition-all duration-200 text-left ${
                selectedLanguage === language.code
                  ? 'border-primary bg-primary/5 shadow-soft'
                  : 'border-border hover:border-primary/50 hover:bg-primary/5'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">{language.native}</div>
                  <div className="text-sm text-muted-foreground">{language.name}</div>
                </div>
                {selectedLanguage === language.code && (
                  <Check className="w-5 h-5 text-primary" />
                )}
              </div>
            </button>
          ))}
        </div>

        <Button 
          onClick={onNext}
          className="w-full btn-hero"
        >
          Continue
        </Button>
      </Card>
    </div>
  );
}