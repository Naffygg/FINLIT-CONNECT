import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";
import { CheckCircle, XCircle, Trophy, ArrowRight } from "lucide-react";

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const sampleQuiz: Question[] = [
  {
    id: 1,
    question: "What percentage of your income should you ideally save each month?",
    options: ["5%", "10%", "20%", "50%"],
    correctAnswer: 2,
    explanation: "Financial experts recommend saving at least 20% of your income - 10% for emergency fund and 10% for long-term goals."
  },
  {
    id: 2,
    question: "Which of these is the safest way to send money in Nigeria?",
    options: ["Sharing your ATM PIN", "Using registered mobile banking apps", "Sending cash with strangers", "Writing your password on paper"],
    correctAnswer: 1,
    explanation: "Registered mobile banking apps like those from established banks are the safest way to transfer money digitally."
  },
  {
    id: 3,
    question: "What should you do before making any investment?",
    options: ["Ask friends for advice", "Research and understand the risks", "Invest all your savings", "Follow social media tips"],
    correctAnswer: 1,
    explanation: "Always research and understand the risks involved in any investment before putting your money in."
  }
];

interface QuizComponentProps {
  onComplete: (score: number) => void;
}

export default function QuizComponent({ onComplete }: QuizComponentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNext = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);

    if (selectedAnswer === sampleQuiz[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    setShowResult(true);
  };

  const handleContinue = () => {
    if (currentQuestion < sampleQuiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      onComplete(score);
    }
  };

  const currentQ = sampleQuiz[currentQuestion];
  const progress = ((currentQuestion + 1) / sampleQuiz.length) * 100;
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="container mx-auto max-w-2xl">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-primary">Savings Challenge Quiz</h1>
            <div className="points-display">
              Question {currentQuestion + 1}/{sampleQuiz.length}
            </div>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="p-6 shadow-strong">
          {!showResult ? (
            <>
              {/* Question */}
              <div className="mb-8">
                <h2 className="text-xl font-bold mb-6">{currentQ.question}</h2>
                
                <div className="space-y-3">
                  {currentQ.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(index)}
                      className={`w-full p-4 text-left border-2 rounded-lg transition-all duration-200 ${
                        selectedAnswer === index
                          ? 'border-primary bg-primary/5 shadow-soft'
                          : 'border-border hover:border-primary/50 hover:bg-primary/5'
                      }`}
                    >
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded-full border-2 mr-3 flex items-center justify-center ${
                          selectedAnswer === index 
                            ? 'border-primary bg-primary text-primary-foreground' 
                            : 'border-muted'
                        }`}>
                          {selectedAnswer === index && <div className="w-2 h-2 bg-current rounded-full" />}
                        </div>
                        <span className="font-medium">{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <Button 
                onClick={handleNext}
                disabled={selectedAnswer === null}
                className="w-full btn-hero"
              >
                Submit Answer
              </Button>
            </>
          ) : (
            <>
              {/* Result */}
              <div className="text-center mb-8">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                  isCorrect ? 'bg-success/10' : 'bg-destructive/10'
                }`}>
                  {isCorrect ? (
                    <CheckCircle className="w-10 h-10 text-success" />
                  ) : (
                    <XCircle className="w-10 h-10 text-destructive" />
                  )}
                </div>
                
                <h3 className={`text-2xl font-bold mb-2 ${
                  isCorrect ? 'text-success' : 'text-destructive'
                }`}>
                  {isCorrect ? 'Correct!' : 'Not quite!'}
                </h3>
                
                <p className="text-muted-foreground mb-6">
                  {currentQ.explanation}
                </p>

                {isCorrect && (
                  <div className="badge-earned inline-flex items-center">
                    <Trophy className="w-4 h-4 mr-2" />
                    +50 points earned!
                  </div>
                )}
              </div>

              <Button 
                onClick={handleContinue}
                className="w-full btn-hero"
              >
                {currentQuestion < sampleQuiz.length - 1 ? (
                  <>Next Question <ArrowRight className="ml-2 w-4 h-4" /></>
                ) : (
                  <>Complete Quiz <Trophy className="ml-2 w-4 h-4" /></>
                )}
              </Button>
            </>
          )}
        </Card>

        {/* Score Tracker */}
        <div className="mt-6 text-center">
          <div className="inline-flex items-center space-x-4 bg-card border border-border rounded-lg px-6 py-3">
            <div>
              <span className="text-sm text-muted-foreground">Current Score: </span>
              <span className="font-bold text-success">{score}/{currentQuestion + (showResult ? 1 : 0)}</span>
            </div>
            <div>
              <span className="text-sm text-muted-foreground">Points: </span>
              <span className="font-bold text-accent">{score * 50}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}