import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import LanguageSelector from "./LanguageSelector";
import { ArrowRight, User, Calendar } from "lucide-react";

interface OnboardingFlowProps {
  onComplete: (userData: {
    name: string;
    age: string;
    language: string;
  }) => void;
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(0);
  const [userData, setUserData] = useState({
    name: '',
    age: '',
    language: 'en'
  });

  const handleLanguageSelect = (language: string) => {
    setUserData({ ...userData, language });
  };

  const handleNext = () => {
    if (step < 2) {
      setStep(step + 1);
    } else {
      onComplete(userData);
    }
  };

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  if (step === 0) {
    return (
      <LanguageSelector 
        onLanguageSelect={handleLanguageSelect}
        onNext={handleNext}
      />
    );
  }

  if (step === 1) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-6 shadow-strong">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-primary mb-2">Tell us about yourself</h2>
            <p className="text-muted-foreground">Help us personalize your learning experience</p>
          </div>

          <div className="space-y-4 mb-6">
            <div>
              <Label htmlFor="name">Your Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="Enter your name"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="age">Your Age</Label>
              <Input
                id="age"
                type="number"
                placeholder="Enter your age"
                value={userData.age}
                onChange={(e) => setUserData({ ...userData, age: e.target.value })}
                className="mt-1"
                min="15"
                max="35"
              />
            </div>
          </div>

          <div className="flex space-x-3">
            <Button 
              onClick={handlePrevious}
              variant="outline"
              className="flex-1"
            >
              Previous
            </Button>
            <Button 
              onClick={handleNext}
              disabled={!userData.name || !userData.age}
              className="flex-1 btn-hero"
            >
              Next <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-6 shadow-strong">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Calendar className="w-8 h-8 text-success" />
          </div>
          <h2 className="text-2xl font-bold text-primary mb-2">Welcome, {userData.name}!</h2>
          <p className="text-muted-foreground">You're all set to start your financial literacy journey</p>
        </div>

        <div className="bg-secondary/50 rounded-lg p-4 mb-6">
          <h3 className="font-bold mb-3">What you'll get:</h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center">
              <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
              Personalized learning in {userData.language === 'en' ? 'English' : userData.language}
            </li>
            <li className="flex items-center">
              <div className="w-2 h-2 bg-success rounded-full mr-3"></div>
              Interactive modules and quizzes
            </li>
            <li className="flex items-center">
              <div className="w-2 h-2 bg-accent rounded-full mr-3"></div>
              Real rewards and certificates
            </li>
            <li className="flex items-center">
              <div className="w-2 h-2 bg-warning rounded-full mr-3"></div>
              Access to financial mentors
            </li>
          </ul>
        </div>

        <Button 
          onClick={handleNext}
          className="w-full btn-hero"
        >
          Start Learning Journey! <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </Card>
    </div>
  );
}