import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, BookOpen, Users, Trophy, Gift } from "lucide-react";
import heroImage from "@/assets/hero-image.jpg";

interface HeroProps {
  onStartLearning: () => void;
}

export default function Hero({ onStartLearning }: HeroProps) {
  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Header */}
      <header className="flex items-center justify-between p-4 md:p-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-white">FinLit Connect</h1>
        </div>
        <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
          Login
        </Button>
      </header>

      {/* Hero Content */}
      <div className="container mx-auto px-4 py-8 md:py-16">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Master Money,<br />
              <span className="text-accent">Build Wealth</span>
            </h2>
            <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed">
              Join thousands of Nigerian youth learning financial literacy through 
              gamified modules, expert mentorship, and real rewards.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                onClick={onStartLearning}
                className="btn-hero text-lg px-8 py-4"
              >
                Start Learning <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button variant="outline" className="text-white border-white/20 hover:bg-white/10 text-lg px-8 py-4">
                Watch Demo
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-accent">50K+</div>
                <div className="text-sm text-white/80">Active Learners</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">200+</div>
                <div className="text-sm text-white/80">Expert Mentors</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">₦5M+</div>
                <div className="text-sm text-white/80">Rewards Given</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <img 
              src={heroImage} 
              alt="Nigerian youth learning financial literacy"
              className="rounded-2xl shadow-strong w-full h-auto"
            />
            
            {/* Floating Cards */}
            <Card className="absolute -top-4 -left-4 p-4 shadow-strong">
              <div className="flex items-center space-x-3">
                <Trophy className="w-8 h-8 text-accent" />
                <div>
                  <div className="font-bold text-sm">Achievement Unlocked!</div>
                  <div className="text-xs text-muted-foreground">Savings Master</div>
                </div>
              </div>
            </Card>

            <Card className="absolute -bottom-4 -right-4 p-4 shadow-strong">
              <div className="flex items-center space-x-3">
                <Gift className="w-8 h-8 text-success" />
                <div>
                  <div className="font-bold text-sm">Reward Earned!</div>
                  <div className="text-xs text-muted-foreground">₦500 Airtime</div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Features Preview */}
      <div className="container mx-auto px-4 pb-16">
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="module-card text-center">
            <BookOpen className="w-12 h-12 text-primary mx-auto mb-4" />
            <h3 className="font-bold mb-2">Interactive Lessons</h3>
            <p className="text-sm text-muted-foreground">Bite-sized modules in your local language</p>
          </Card>
          
          <Card className="module-card text-center">
            <Trophy className="w-12 h-12 text-accent mx-auto mb-4" />
            <h3 className="font-bold mb-2">Gamification</h3>
            <p className="text-sm text-muted-foreground">Earn points, badges, and climb leaderboards</p>
          </Card>
          
          <Card className="module-card text-center">
            <Users className="w-12 h-12 text-success mx-auto mb-4" />
            <h3 className="font-bold mb-2">Expert Mentors</h3>
            <p className="text-sm text-muted-foreground">Connect with financial professionals</p>
          </Card>
          
          <Card className="module-card text-center">
            <Gift className="w-12 h-12 text-warning mx-auto mb-4" />
            <h3 className="font-bold mb-2">Real Rewards</h3>
            <p className="text-sm text-muted-foreground">Airtime, tokens, and certificates</p>
          </Card>
        </div>
      </div>
    </div>
  );
}