import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, 
  Trophy, 
  Users, 
  Gift,
  TrendingUp,
  Clock,
  Star,
  Target,
  Zap,
  Award
} from "lucide-react";

interface DashboardProps {
  userName?: string;
  userLanguage?: string;
  onStartQuiz: () => void;
}

export default function Dashboard({ userName = "Adebayo", userLanguage = "English", onStartQuiz }: DashboardProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-primary text-primary-foreground p-4 md:p-6">
        <div className="container mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Welcome back, {userName}! 👋</h1>
              <p className="text-primary-foreground/80">Ready to level up your financial game?</p>
            </div>
            <div className="points-display">
              <Zap className="inline w-4 h-4 mr-1" />
              2,350 pts
            </div>
          </div>

          {/* Quick Stats */}
          <div className="stats-grid">
            <div className="text-center">
              <div className="text-2xl font-bold">Level 7</div>
              <div className="text-sm text-primary-foreground/80">Money Master</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">12/15</div>
              <div className="text-sm text-primary-foreground/80">Modules Done</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">8</div>
              <div className="text-sm text-primary-foreground/80">Badges Earned</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">₦1,200</div>
              <div className="text-sm text-primary-foreground/80">Rewards Earned</div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-4 space-y-8">
        {/* Continue Learning */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <BookOpen className="w-6 h-6 mr-2 text-primary" />
            Continue Learning
          </h2>
          
          <Card className="module-card bg-gradient-to-r from-primary/10 to-success/10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-bold text-lg">Investment Basics</h3>
                <p className="text-muted-foreground">Learn how to grow your money</p>
              </div>
              <div className="progress-ring text-xs">
                70%
              </div>
            </div>
            <Progress value={70} className="mb-4" />
            <Button className="btn-hero">
              Continue Module <Target className="ml-2 w-4 h-4" />
            </Button>
          </Card>
        </section>

        {/* Learning Modules */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Trophy className="w-6 h-6 mr-2 text-accent" />
            Available Modules
          </h2>
          
          <div className="modules-grid">
            <Card className="module-card">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold mb-2">Budgeting 101</h3>
              <p className="text-sm text-muted-foreground mb-4">Master the art of managing your money</p>
              <div className="flex items-center justify-between">
                <span className="badge-earned">4 lessons</span>
                <Button size="sm" onClick={onStartQuiz} className="btn-accent">Start Quiz</Button>
              </div>
            </Card>

            <Card className="module-card">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mb-4">
                <Target className="w-6 h-6 text-success" />
              </div>
              <h3 className="font-bold mb-2">Savings Challenge</h3>
              <p className="text-sm text-muted-foreground mb-4">Learn to save ₦500 weekly effectively</p>
              <div className="flex items-center justify-between">
                <span className="badge-earned">6 lessons</span>
                <Button size="sm" className="btn-accent">Start</Button>
              </div>
            </Card>

            <Card className="module-card">
              <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mb-4">
                <Award className="w-6 h-6 text-warning" />
              </div>
              <h3 className="font-bold mb-2">Scam Prevention</h3>
              <p className="text-sm text-muted-foreground mb-4">Protect yourself from financial fraud</p>
              <div className="flex items-center justify-between">
                <span className="badge-earned">5 lessons</span>
                <Button size="sm" className="btn-accent">Start</Button>
              </div>
            </Card>
          </div>
        </section>

        {/* Achievements */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Star className="w-6 h-6 mr-2 text-accent" />
            Recent Achievements
          </h2>
          
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="p-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-bold">Savings Streak Master!</h3>
                  <p className="text-sm text-muted-foreground">Saved money for 30 days straight</p>
                </div>
              </div>
            </Card>

            <Card className="p-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-success/10 rounded-full flex items-center justify-center">
                  <Award className="w-6 h-6 text-success" />
                </div>
                <div>
                  <h3 className="font-bold">Quiz Champion</h3>
                  <p className="text-sm text-muted-foreground">Perfect score on Budget Basics quiz</p>
                </div>
              </div>
            </Card>
          </div>
        </section>

        {/* Community & Mentorship */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Users className="w-6 h-6 mr-2 text-success" />
            Community
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="mentor-card">
              <h3 className="font-bold mb-4">Ask a Mentor</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Get personalized advice from financial experts
              </p>
              <Button variant="outline" className="w-full">
                Connect with Mentor
              </Button>
            </Card>

            <Card className="mentor-card">
              <h3 className="font-bold mb-4">Community Discussions</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Join conversations with fellow learners
              </p>
              <Button variant="outline" className="w-full">
                Join Discussion
              </Button>
            </Card>
          </div>
        </section>

        {/* Rewards */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Gift className="w-6 h-6 mr-2 text-warning" />
            Available Rewards
          </h2>
          
          <div className="grid md:grid-cols-3 gap-4">
            <Card className="p-4 text-center">
              <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-success" />
              </div>
              <h3 className="font-bold mb-2">₦200 Airtime</h3>
              <p className="text-sm text-muted-foreground mb-4">Complete 3 more modules</p>
              <Button size="sm" variant="outline" className="w-full">
                <Clock className="w-4 h-4 mr-2" />
                In Progress
              </Button>
            </Card>

            <Card className="p-4 text-center">
              <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-accent" />
              </div>
              <h3 className="font-bold mb-2">Certificate</h3>
              <p className="text-sm text-muted-foreground mb-4">Finish all basic modules</p>
              <Button size="sm" className="w-full btn-accent">
                Claim Now!
              </Button>
            </Card>

            <Card className="p-4 text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-warning" />
              </div>
              <h3 className="font-bold mb-2">Bonus Points</h3>
              <p className="text-sm text-muted-foreground mb-4">Refer 2 friends</p>
              <Button size="sm" variant="outline" className="w-full">
                Share App
              </Button>
            </Card>
          </div>
        </section>
      </div>
    </div>
  );
}